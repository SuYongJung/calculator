enum CalculatorError: Error {
    case operatorError
    case divideByZero
}

class Calculator {
    var operator2: String
    var firstNumber: Int
    var secondNumber: Int
    
    init(operator2: String, firstNumber: Int, secondNumber: Int) {
        self.operator2 = operator2
        self.firstNumber = firstNumber
        self.secondNumber = secondNumber
    }
    
    func calculate() throws -> Int {
        switch operator2 {
        case "+":
            return firstNumber + secondNumber
        case "-":
            return firstNumber - secondNumber
        case "*":
            return firstNumber * secondNumber
        case "/":
            if secondNumber == 0 {
                throw CalculatorError.divideByZero
            }
            return firstNumber / secondNumber
        case "%":
            return firstNumber % secondNumber
        default :
            throw CalculatorError.operatorError
        }
    }
}

var calculator = Calculator(operator2: "/", firstNumber: 15, secondNumber: 0)

do {
    let content = try calculator.calculate()
    print("결과값: \(content)")
} catch CalculatorError.divideByZero {
    print("0으로 나누어 에러가 발생했습니다")
} catch CalculatorError.operatorError {
    print("사칙연산과 나머지 연산자 외에 입력하셔서 에러가 발생했습니다.")
}


print(try calculator.calculate())
